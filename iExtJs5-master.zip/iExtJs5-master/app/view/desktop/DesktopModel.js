/* 
 * 视图模型 - 首页
 */

Ext.define("App.view.desktop.DesktopModel", {
	extend: "Ext.app.ViewModel",
	alias: "viewmodel.desktop",
	
	data: {},
	stores: {}
});