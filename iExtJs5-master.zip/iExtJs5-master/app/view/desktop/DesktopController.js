/* 
 * 视图控制器 - 首页
 */

Ext.define("App.view.desktop.DesktopController", {
	extend: "Ext.app.ViewController",
	alias: "controller.desktop"
	
});