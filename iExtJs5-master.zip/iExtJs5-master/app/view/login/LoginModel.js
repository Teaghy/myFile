Ext.define("App.view.login.LoginModel", {
	extend: "Ext.app.ViewModel",
	alias: "viewmodel.login",
	
	data: {
		username: "Neo",
		password: "123456"
	}
});
