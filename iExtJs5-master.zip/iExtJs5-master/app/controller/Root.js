/*
 * Global Controller 
 */

Ext.define("App.controller.Root", {
	extend: "Ext.app.Controller",
	
	requires: [],
	
	onLaunch: function() {}
});