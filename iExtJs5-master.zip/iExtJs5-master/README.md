# iExtJs5

一个基于ExtJs5实现，简洁完整的后台管理系统入门实例

系统简介：http://blog.csdn.net/hwhsong/article/details/50544428